package ru.nsu.salina.model.message;

public enum MessageType {
    BASIC_MASSAGE,
    PING_MASSAGE,
}
