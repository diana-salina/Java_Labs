package ru.nsu.salina.model.client.controller;

public class Controller {
}
